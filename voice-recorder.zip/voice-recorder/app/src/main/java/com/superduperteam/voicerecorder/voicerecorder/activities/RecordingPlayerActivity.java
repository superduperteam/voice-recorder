package com.superduperteam.voicerecorder.voicerecorder.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.superduperteam.voicerecorder.voicerecorder.R;

public class RecordingPlayerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recording_player);


    }
}
